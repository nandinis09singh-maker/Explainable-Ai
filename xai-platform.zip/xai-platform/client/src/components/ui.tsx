import type { ReactNode } from "react";
import { bandLabel } from "../format";

export const Loading = ({ label = "Loading" }: { label?: string }) => <div className="state" role="status">{label}…</div>;
export const ErrorBox = ({ message, onRetry }: { message: string; onRetry?: () => void }) => (
  <div className="state error" role="alert">{message}{onRetry && <button className="btn sm" onClick={onRetry}>Retry</button>}</div>
);
export const Empty = ({ children }: { children: ReactNode }) => <div className="state">{children}</div>;
export const Badge = ({ kind, children }: { kind: string; children?: ReactNode }) => <span className={`badge ${kind}`}>{children ?? bandLabel(kind)}</span>;
export const Kpi = ({ label, value, hint }: { label: string; value: ReactNode; hint?: string }) => (
  <div className="kpi"><div className="kpi-v">{value}</div><div className="kpi-l">{label}</div>{hint && <div className="kpi-h">{hint}</div>}</div>
);
export const PageHead = ({ title, sub, actions }: { title: string; sub?: string; actions?: ReactNode }) => (
  <header className="pagehead"><div><h1>{title}</h1>{sub && <p className="muted">{sub}</p>}</div>{actions && <div className="actions">{actions}</div>}</header>
);
