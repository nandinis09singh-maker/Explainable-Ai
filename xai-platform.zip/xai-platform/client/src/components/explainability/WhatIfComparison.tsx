import { Bar, BarChart, CartesianGrid, Legend, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import type { SimResult, Thresholds } from "../../types";
import PredictionCard from "./PredictionCard";

export default function WhatIfComparison({ result, thresholds }: { result: SimResult; thresholds: Thresholds }) {
  const data = result.factor_changes.map((f) => ({ name: f.label, Original: f.original_contribution, Simulated: f.simulated_contribution }));
  return (
    <div className="stack">
      <div className={`callout ${result.class_changed ? "changed" : ""}`} role="status">{result.summary}</div>
      <div className="grid2">
        <PredictionCard title="Original" band={result.original.predicted_class} risk={result.original.risk_probability} thresholds={thresholds} />
        <PredictionCard title="Simulated" band={result.simulated.predicted_class} risk={result.simulated.risk_probability} thresholds={thresholds} />
      </div>
      <div className="card">
        <h3>Factors responsible for the change</h3>
        <ResponsiveContainer width="100%" height={280}>
          <BarChart data={data} layout="vertical" margin={{ left: 8, right: 24 }}>
            <CartesianGrid horizontal={false} stroke="var(--line)" />
            <XAxis type="number" tick={{ fill: "var(--muted)", fontSize: 11 }} />
            <YAxis type="category" dataKey="name" width={150} tick={{ fill: "var(--fg)", fontSize: 12 }} />
            <Tooltip contentStyle={{ background: "var(--surf2)", border: "1px solid var(--line)", borderRadius: 8 }} />
            <Legend />
            <Bar dataKey="Original" fill="var(--muted)" radius={3} />
            <Bar dataKey="Simulated" fill="var(--accent)" radius={3} />
          </BarChart>
        </ResponsiveContainer>
        <table className="tbl"><thead><tr><th>Factor</th><th className="r">Before</th><th className="r">After</th><th className="r">Change</th></tr></thead>
          <tbody>{result.factor_changes.map((f) => (
            <tr key={f.feature}><td>{f.label}</td><td className="r mono">{f.original_contribution.toFixed(2)}</td><td className="r mono">{f.simulated_contribution.toFixed(2)}</td>
              <td className={`r mono ${f.change > 0.005 ? "bad-t" : f.change < -0.005 ? "good-t" : ""}`}>{f.change > 0 ? "+" : ""}{f.change.toFixed(2)}</td></tr>))}</tbody></table>
      </div>
      <p className="muted small">{result.disclaimer}</p>
    </div>
  );
}
