import { Bar, BarChart, Cell, CartesianGrid, ReferenceLine, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import type { Explanation } from "../../types";
import { featureValue } from "../../format";

const css = (n: string) => `var(${n})`;

export default function FeatureContributionChart({ items, height = 260 }: { items: Explanation[]; height?: number }) {
  const data = items.map((e) => ({ ...e, name: e.label }));
  const lim = Math.max(0.3, ...items.map((e) => Math.abs(e.contribution))) * 1.15;
  return (
    <div role="img" aria-label="Feature contributions to estimated default risk">
      <ResponsiveContainer width="100%" height={height}>
        <BarChart data={data} layout="vertical" margin={{ left: 8, right: 24, top: 4, bottom: 4 }}>
          <CartesianGrid horizontal={false} stroke={css("--line")} />
          <XAxis type="number" domain={[-lim, lim]} tick={{ fill: css("--muted"), fontSize: 11 }} tickFormatter={(v) => v.toFixed(1)} />
          <YAxis type="category" dataKey="name" width={150} tick={{ fill: css("--fg"), fontSize: 12 }} />
          <ReferenceLine x={0} stroke={css("--muted")} />
          <Tooltip cursor={{ fill: "rgba(128,128,128,.12)" }}
            content={({ active, payload }) => {
              if (!active || !payload?.length) return null;
              const e = payload[0].payload as Explanation;
              return (<div className="tip"><b>{e.label}</b><br />Value: {featureValue(e.feature, e.value)}<br />
                Contribution: {e.contribution > 0 ? "+" : ""}{e.contribution.toFixed(3)} log-odds<br />
                {e.direction === "increases_risk" ? "Raises risk" : e.direction === "reduces_risk" ? "Lowers risk" : "No real effect"}</div>);
            }} />
          <Bar dataKey="contribution" radius={3}>
            {data.map((e) => <Cell key={e.feature} fill={e.contribution > 0 ? css("--bad") : css("--good")} />)}
          </Bar>
        </BarChart>
      </ResponsiveContainer>
      <p className="muted small">Red pushes estimated default risk up, green pulls it down. Units are SHAP values in log-odds.</p>
    </div>
  );
}
