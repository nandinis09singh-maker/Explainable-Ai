import type { Band, Thresholds } from "../../types";
import { bandLabel, pct } from "../../format";
import { Badge } from "../ui";

export default function PredictionCard({ band, risk, thresholds, reasons, title = "Prediction" }:
  { band: Band; risk: number; thresholds: Thresholds; reasons?: string[]; title?: string }) {
  const a = thresholds.approve_below * 100, r = thresholds.reject_at_or_above * 100;
  return (
    <div className="card pred">
      <div className="row between"><h3>{title}</h3><Badge kind={band}>{bandLabel(band)}</Badge></div>
      <div className="risk"><span className="risk-v">{pct(risk, 1)}</span><span className="muted">estimated default risk</span></div>
      <div className="gauge" role="img" aria-label={`Risk ${pct(risk, 1)} on a scale with approve below ${a}% and reject from ${r}%`}>
        <i className="z approve" style={{ width: `${a}%` }} /><i className="z review" style={{ width: `${r - a}%` }} /><i className="z reject" style={{ width: `${100 - r}%` }} />
        <b className="needle" style={{ left: `${Math.min(99.5, risk * 100)}%` }} />
      </div>
      <div className="gauge-l"><span>0%</span><span>{a}%</span><span>{r}%</span><span>100%</span></div>
      {reasons && <ul className="reasons">{reasons.map((x) => <li key={x}>{x}</li>)}</ul>}
    </div>
  );
}
