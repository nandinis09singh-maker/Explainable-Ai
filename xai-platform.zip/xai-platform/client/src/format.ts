export const pct = (p: number, d = 0) => `${(p * 100).toFixed(d)}%`;
export const inr = (v: number) => `₹${Math.round(v).toLocaleString("en-IN")}`;
export const when = (iso: string) => new Date(iso).toLocaleString("en-IN", { dateStyle: "medium", timeStyle: "short" });
export const bandLabel = (b: string) => ({ approve: "Approve", review: "Needs review", reject: "Reject" } as Record<string, string>)[b] ?? b;
export const featureValue = (feature: string, v: number) =>
  feature === "credit_utilization" ? pct(v) : feature === "repayment_history_score" ? v.toFixed(2) : inr(v);
