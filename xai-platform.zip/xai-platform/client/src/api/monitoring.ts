import { api } from "./client";
import type { AuditRecord, Monitoring } from "../types";
import type { Filters } from "./decisions";

export const monitoringSummary = () => api.get<Monitoring>("/api/monitoring/summary").then((r) => r.data);
export const auditRecords = (f: Filters = {}) =>
  api.get<AuditRecord[]>("/api/audit", { params: Object.fromEntries(Object.entries(f).filter(([, v]) => v)) }).then((r) => r.data);
