import { api } from "./client";

/** Fetches the PDF through axios (so the API key header is sent) and triggers a browser download. */
export async function downloadReport(id: string): Promise<void> {
  const res = await api.get<Blob>(`/api/reports/${id}/pdf`, { responseType: "blob" });
  const url = URL.createObjectURL(res.data);
  const a = document.createElement("a");
  a.href = url;
  a.download = `${id}-explainability-report.pdf`;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}
