import { api } from "./client";
import type { Decision, DecisionSummary, Health, Inputs, Overview, SimResult } from "../types";

export interface Filters { q?: string; predicted_class?: string; review_status?: string; date_from?: string; date_to?: string }
const clean = (f: Filters) => Object.fromEntries(Object.entries(f).filter(([, v]) => v));

export const health = () => api.get<Health>("/api/health").then((r) => r.data);
export const overview = () => api.get<Overview>("/api/overview").then((r) => r.data);
export const listDecisions = (f: Filters = {}) => api.get<DecisionSummary[]>("/api/decisions", { params: clean(f) }).then((r) => r.data);
export const getDecision = (id: string) => api.get<Decision>(`/api/decisions/${id}`).then((r) => r.data);
export const predict = (body: Inputs & { applicant_label?: string; region?: string; age_band?: string }) =>
  api.post<Decision>("/api/decisions/predict", body).then((r) => r.data);
export const simulate = (id: string, changes: Partial<Inputs>) =>
  api.post<SimResult>(`/api/decisions/${id}/simulate`, changes).then((r) => r.data);
export const review = (id: string, body: { reviewer: string; action: string; notes: string }) =>
  api.post<Decision>(`/api/decisions/${id}/review`, body).then((r) => r.data);
