import axios from "axios";

export const API_BASE: string = (import.meta.env.VITE_API_URL as string | undefined) ?? "";

export const api = axios.create({ baseURL: API_BASE });

// Optional API key for deployments that set API_KEY on the server.
api.interceptors.request.use((cfg) => {
  try {
    const key = localStorage.getItem("xai_api_key");
    if (key) cfg.headers.set("X-API-Key", key);
  } catch { /* storage unavailable */ }
  return cfg;
});

export function errorMessage(e: unknown): string {
  if (axios.isAxiosError(e)) {
    const d = e.response?.data?.detail;
    if (Array.isArray(d)) return d.map((x) => `${x.loc?.slice(1).join(".")}: ${x.msg}`).join("; ");
    if (typeof d === "string") return d;
    if (!e.response) return "Cannot reach the API. Is the FastAPI server running on port 8000?";
    return `Request failed (${e.response.status})`;
  }
  return e instanceof Error ? e.message : "Something went wrong";
}
