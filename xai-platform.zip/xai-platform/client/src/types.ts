export type Band = "approve" | "review" | "reject";
export type Direction = "increases_risk" | "reduces_risk" | "neutral";

export interface Inputs {
  annual_income: number;
  loan_amount: number;
  existing_monthly_debt: number;
  credit_utilization: number;
  repayment_history_score: number;
}
export interface Explanation { feature: keyof Inputs; label: string; value: number; contribution: number; direction: Direction }
export interface AuditEvent { id: number; decision_id: string; ts: string; actor: string; action: string; detail: string }
export interface Thresholds { approve_below: number; reject_at_or_above: number }
export interface DecisionSummary {
  decision_id: string; created_at: string; model_version: string; applicant_label: string;
  predicted_class: Band; risk_probability: number; review_status: string;
}
export interface Decision extends DecisionSummary {
  region: string; age_band: string; inputs: Inputs; base_value: number; explanations: Explanation[];
  reasons: string[]; thresholds: Thresholds; events: AuditEvent[]; demo_mode: boolean;
}
export interface SimSide { inputs: Inputs; predicted_class: Band; risk_probability: number; explanations: Explanation[] }
export interface FactorChange { feature: string; label: string; original_contribution: number; simulated_contribution: number; change: number }
export interface SimResult {
  decision_id: string; original: SimSide; simulated: SimSide; risk_change: number; class_changed: boolean;
  factor_changes: FactorChange[]; summary: string; disclaimer: string;
}
export interface Alert { date: string; severity: "high" | "medium" | "info"; kind: string; message: string }
export interface GroupRow { group: string; n: number; approval_rate: number; mean_risk: number }
export interface Monitoring {
  model_version: string; thresholds: Thresholds; limitations: string[]; class_mix: Record<Band, number>; alerts: Alert[];
  dataset: { name: string; train_rows: number; eval_rows: number; evaluation_period: string; drift_window: string };
  performance: { roc_auc: number; accuracy_at_review_cutoff: number; precision_at_review_cutoff: number; recall_at_review_cutoff: number; brier_score: number; default_rate: number };
  calibration: { predicted: number; observed: number }[];
  fairness: Record<string, { groups: GroupRow[]; max_gap: number; disparate_impact_ratio: number | null }>;
  drift: { feature: string; psi: number; status: "stable" | "watch" | "alert" }[];
}
export interface Overview {
  total: number; by_class: Record<Band, number>; by_review_status: Record<string, number>; model_version: string; roc_auc: number;
  min_disparate_impact_ratio: number; alerts: Alert[];
  recent: { decision_id: string; created_at: string; predicted_class: Band; risk_probability: number; review_status: string }[];
}
export interface AuditRecord {
  decision_id: string; created_at: string; model_version: string; predicted_class: Band; risk_probability: number; review_status: string;
  event_count: number; top_factor: string | null; explanations: Explanation[]; reasons: string[]; events: AuditEvent[];
}
export interface Health { status: string; model_version: string; thresholds: Thresholds; database: string; demo_mode: boolean; features: string[]; probability_meaning: string }
