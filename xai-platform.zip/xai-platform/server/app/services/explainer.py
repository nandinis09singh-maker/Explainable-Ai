"""Per-decision SHAP contributions (TreeExplainer matches the gradient-boosted tree model).
Contributions are in log-odds of default; positive values push risk up."""
from __future__ import annotations

from functools import lru_cache

import shap

from . import predictor

LABELS = {
    "annual_income": "Annual income",
    "loan_amount": "Loan amount",
    "existing_monthly_debt": "Existing monthly debt",
    "credit_utilization": "Credit utilization",
    "repayment_history_score": "Repayment history score",
}


def fmt(feature: str, v: float) -> str:
    if feature in ("annual_income", "loan_amount", "existing_monthly_debt"):
        return f"₹{v:,.0f}"
    if feature == "credit_utilization":
        return f"{v * 100:.0f}%"
    return f"{v:.2f}"


@lru_cache(maxsize=1)
def _explainer() -> shap.TreeExplainer:
    return shap.TreeExplainer(predictor.model())


def explain(inputs: dict) -> tuple[list[dict], float]:
    frame = predictor.to_frame(inputs)
    ex = _explainer()
    values = ex.shap_values(frame)[0]
    base = float(ex.expected_value if not hasattr(ex.expected_value, "__len__") else ex.expected_value[0])
    items = []
    for f, c in zip(predictor.features(), values):
        c = float(c)
        items.append({
            "feature": f, "label": LABELS[f], "value": float(inputs[f]), "contribution": round(c, 4),
            "direction": "increases_risk" if c > 0.005 else "reduces_risk" if c < -0.005 else "neutral",
        })
    items.sort(key=lambda x: abs(x["contribution"]), reverse=True)
    return items, round(base, 4)


def reasons(items: list[dict], predicted_class: str, risk: float, top: int = 4) -> list[str]:
    out = [f"The model estimates a {risk * 100:.0f}% chance of default, which falls in the '{predicted_class}' band."]
    for it in items[:top]:
        if it["direction"] == "neutral":
            continue
        verb = "raises" if it["direction"] == "increases_risk" else "lowers"
        out.append(f"{it['label']} ({fmt(it['feature'], it['value'])}) {verb} the estimated risk.")
    return out
