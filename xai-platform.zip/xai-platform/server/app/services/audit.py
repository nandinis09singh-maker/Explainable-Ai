from sqlalchemy.orm import Session

from .. import models


def record(db: Session, decision_id: str, actor: str, action: str, detail: str = "", ts=None) -> models.AuditEvent:
    ev = models.AuditEvent(decision_id=decision_id, actor=actor, action=action, detail=detail, ts=ts or models.now())
    db.add(ev)
    return ev


def next_decision_id(db: Session) -> str:
    ids = [int(d[0].split("-")[1]) for d in db.query(models.Decision.id).all() if d[0].startswith("DEMO-")]
    return f"DEMO-{(max(ids) + 1) if ids else 1001}"
