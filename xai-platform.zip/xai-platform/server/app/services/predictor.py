"""Loads the trusted model artifact once and turns probabilities into classes."""
from __future__ import annotations

import json
from functools import lru_cache
from pathlib import Path

import pandas as pd
import skops.io as sio

ML_DIR = Path(__file__).resolve().parent.parent / "ml"


@lru_cache(maxsize=1)
def meta() -> dict:
    return json.loads((ML_DIR / "model_meta.json").read_text())


@lru_cache(maxsize=1)
def model():
    path = ML_DIR / "model_artifact.skops"
    # The artifact is created by ml/train_model.py in this repo. Only load files you created and trust.
    return sio.load(path, trusted=sio.get_untrusted_types(file=path))


def features() -> list[str]:
    return meta()["features"]


def to_frame(inputs: dict) -> pd.DataFrame:
    return pd.DataFrame([{f: float(inputs[f]) for f in features()}])


def classify(p: float) -> str:
    t = meta()["thresholds"]
    if p < t["approve_below"]:
        return "approve"
    if p >= t["reject_at_or_above"]:
        return "reject"
    return "review"


def predict(inputs: dict) -> tuple[float, str]:
    p = float(model().predict_proba(to_frame(inputs))[0, 1])
    return p, classify(p)
