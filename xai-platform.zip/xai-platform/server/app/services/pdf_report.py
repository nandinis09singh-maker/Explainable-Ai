"""Builds the explainability evidence report for a saved decision (ReportLab)."""
from __future__ import annotations

from io import BytesIO

from reportlab.graphics import renderPDF
from reportlab.graphics.shapes import Drawing, Line, Rect, String
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle

from .. import models
from . import explainer, predictor

def rs(t: str) -> str:
    """Built-in PDF fonts have no rupee glyph, so print Rs instead."""
    return t.replace("₹", "Rs ")


INK, MUTED, LINE = colors.HexColor("#0f1b33"), colors.HexColor("#5b6b8c"), colors.HexColor("#cdd6e6")
UP, DOWN = colors.HexColor("#c63f27"), colors.HexColor("#0b8f7c")


def _bars(items: list[dict], width: float = 170 * mm) -> Drawing:
    row, h = 16, 16 * len(items) + 14
    d = Drawing(width, h)
    mid, scale = width * 0.62, (width * 0.28) / max(0.01, max(abs(i["contribution"]) for i in items))
    d.add(Line(mid, 4, mid, h - 8, strokeColor=LINE))
    for n, it in enumerate(items):
        y = h - 14 - n * row
        c = it["contribution"]
        d.add(String(0, y + 2, it["label"], fontSize=8, fontName="Helvetica", fillColor=INK))
        w = abs(c) * scale
        d.add(Rect(mid if c >= 0 else mid - w, y, max(w, 0.5), 9, fillColor=UP if c > 0 else DOWN, strokeColor=None))
        d.add(String(mid + (w + 4 if c >= 0 else -w - 4), y + 2, f"{c:+.2f}", fontSize=7, fontName="Helvetica", fillColor=MUTED, textAnchor="start" if c >= 0 else "end"))
    return d


def build(d: models.Decision) -> bytes:
    meta = predictor.meta()
    ss = getSampleStyleSheet()
    h1 = ParagraphStyle("h1", parent=ss["Title"], fontSize=20, textColor=INK, alignment=0, spaceAfter=4)
    h2 = ParagraphStyle("h2", parent=ss["Heading2"], fontSize=12, textColor=INK, spaceBefore=12, spaceAfter=4)
    body = ParagraphStyle("b", parent=ss["BodyText"], fontSize=9.5, leading=13, textColor=INK)
    small = ParagraphStyle("s", parent=body, fontSize=8, textColor=MUTED)
    buf = BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=A4, leftMargin=20 * mm, rightMargin=20 * mm, topMargin=18 * mm, bottomMargin=18 * mm,
                            title=f"Explainability report {d.id}", author="Explainable AI demo")
    s = [Paragraph("Explainability &amp; Decision Report", h1),
         Paragraph(f"Decision {d.id} &nbsp;·&nbsp; model {d.model_version} &nbsp;·&nbsp; {d.created_at:%d %b %Y %H:%M} UTC", small),
         Paragraph("DEMO MODE: synthetic data, not a lending recommendation.", ParagraphStyle("w", parent=small, textColor=UP)), Spacer(1, 6)]

    s.append(Paragraph("Outcome", h2))
    t = meta["thresholds"]
    s.append(Paragraph(f"<b>{d.predicted_class.upper()}</b> &nbsp; estimated default risk <b>{d.risk_probability * 100:.1f}%</b> &nbsp; review status: <b>{d.review_status}</b>", body))
    s.append(Paragraph(f"Bands: approve below {t['approve_below'] * 100:.0f}%, review {t['approve_below'] * 100:.0f}-{t['reject_at_or_above'] * 100:.0f}%, "
                       f"reject at or above {t['reject_at_or_above'] * 100:.0f}%. {meta['probability_meaning']}", small))

    s.append(Paragraph("Applicant inputs", h2))
    rows = [["Feature", "Value"]] + [[explainer.LABELS[f], rs(explainer.fmt(f, d.inputs[f]))] for f in predictor.features()]
    tb = Table(rows, colWidths=[85 * mm, 60 * mm])
    tb.setStyle(TableStyle([("FONTSIZE", (0, 0), (-1, -1), 9), ("TEXTCOLOR", (0, 0), (-1, 0), MUTED), ("LINEBELOW", (0, 0), (-1, -1), 0.25, LINE), ("ALIGN", (1, 0), (1, -1), "RIGHT")]))
    s.append(tb)

    s.append(Paragraph("Top contributing factors (SHAP, log-odds of default)", h2))
    s.append(_bars(d.explanations))
    for r in d.reasons:
        s.append(Paragraph("• " + rs(r), body))
    s.append(Paragraph("Red bars push estimated risk up; green bars pull it down. Base value (average model output): %+.2f log-odds." % d.base_value, small))

    s.append(Paragraph("Review notes and audit trail", h2))
    ev = [["Time (UTC)", "Actor", "Action", "Detail"]] + [[e.ts.strftime("%Y-%m-%d %H:%M"), e.actor, e.action, Paragraph(e.detail or "", small)] for e in d.events]
    te = Table(ev, colWidths=[32 * mm, 30 * mm, 38 * mm, 70 * mm], repeatRows=1)
    te.setStyle(TableStyle([("FONTSIZE", (0, 0), (-1, -1), 8), ("TEXTCOLOR", (0, 0), (-1, 0), MUTED), ("LINEBELOW", (0, 0), (-1, -1), 0.25, LINE), ("VALIGN", (0, 0), (-1, -1), "TOP")]))
    s.append(te)

    s.append(Paragraph("Model and limitations", h2))
    s.append(Paragraph(f"Model {meta['model_version']} · ROC AUC {meta['performance']['roc_auc']:.2f} on a synthetic hold-out set · {meta['dataset']['name']}.", body))
    for l in meta["limitations"]:
        s.append(Paragraph("• " + l, body))
    doc.build(s)
    return buf.getvalue()
