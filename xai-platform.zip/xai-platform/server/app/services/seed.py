"""Fills an empty database with synthetic demo decisions from ml/demo_applicants.csv."""
from datetime import timedelta

import pandas as pd
from sqlalchemy.orm import Session

from .. import models
from . import audit, explainer, predictor


def seed(db: Session) -> int:
    if db.query(models.Decision).count():
        return 0
    df = pd.read_csv(predictor.ML_DIR / "demo_applicants.csv")
    start = models.now() - timedelta(days=len(df))
    for i, row in df.iterrows():
        inputs = {f: float(row[f]) for f in predictor.features()}
        p, cls = predictor.predict(inputs)
        items, base = explainer.explain(inputs)
        d = models.Decision(
            id=audit.next_decision_id(db), created_at=start + timedelta(days=int(i), hours=int(i * 7 % 24)),
            model_version=predictor.meta()["model_version"], applicant_label=f"Synthetic applicant {i + 1}",
            region=row["region"], age_band=row["age_band"], inputs=inputs, predicted_class=cls,
            risk_probability=round(p, 4), base_value=base, explanations=items,
            reasons=explainer.reasons(items, cls, p),
        )
        db.add(d)
        db.flush()
        audit.record(db, d.id, "system", "prediction_created", f"{d.model_version} predicted '{cls}' at risk {p:.2f}", ts=d.created_at)
        if cls == "review" and i % 3 == 0:
            audit.record(db, d.id, "reviewer.demo", "review_approve", "Seeded demo review.", ts=d.created_at + timedelta(hours=2))
            d.review_status = "approve"
    db.commit()
    return len(df)
